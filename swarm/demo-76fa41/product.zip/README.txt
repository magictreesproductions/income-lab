Instant €2 pixel-pack.
Generated tonight.